
const cardprops = [
    {
        id: 1,
        cardtitle: "Főcím",
        cardtext: "Főszövegnek a helye",
        cardtags: "tag1, tag2"
    },
    {
        id: 2,
        cardtitle: "Title2",
        cardtext: "Nagyobb mennyiségű szöveg egy kártyán belül, stilisztikai problémák keresése",
        cardtags: "tag3, tag4, tagx"
    },
    {
        id: 3,
        cardtitle: "Title3",
        cardtext: "Some text, hope it works",
        cardtags: "tag5, tag6, tagy, tagz",
    },
    {
        id: 4,
        cardtitle: "Title4",
        cardtext: "Negyedik cucc",
        cardtags: "tag7, tag8, tagz",
    },
    {
        id: 5,
        cardtitle: "Főcím",
        cardtext: "Főszövegnek a helye",
        cardtags: "tag1, tag2"
    },
    {
        id: 6,
        cardtitle: "Title2",
        cardtext: "Nagyobb mennyiségű szöveg egy kártyán belül, stilisztikai problémák keresése",
        cardtags: "tag3, tag4, tagx"
    },
    {
        id: 7,
        cardtitle: "Title3",
        cardtext: "Some text, hope it works",
        cardtags: "tag5, tag6, tagy, tagz",
    },
    {
        id: 8,
        cardtitle: "Title4",
        cardtext: "Negyedik cucc",
        cardtags: "tag7, tag8, tagz",
    }
];

export default cardprops;